import argparse
import base64
import subprocess
import urllib.parse
import getpass
import requests
import warnings
import time
warnings.filterwarnings("ignore")

API = 'https://v2-api.cyberghostvpn.com/v2/my'

def get_public_ip():
    try:
        response = requests.get('https://ipinfo.io/ip')
        ip = response.text.strip()  # Видалення зайвих пробілів та символів нового рядка
        return ip
    except requests.RequestException as e:
        return f"Помилка при отриманні публічної IP-адреси: {e}"

def login(username, password, appKey):
    payload = {'userName': username, 'password': password}
    header = {'x-app-key': appKey}
    r = requests.post(f'{API}/account/jwt', json=payload, headers=header)
    jwt = r.json()['jwt']
    return jwt


def getDevice(jwtToken, appKey):
    header = {'x-app-key': appKey, 'Authorization': 'Bearer ' + jwtToken}
    r = requests.get(f'{API}/devices', headers=header)
    #print (r.json())
    devices_json = r.json()
    for index, device in enumerate(devices_json, start=1):
        app_name = device.get('oauthConsumers', {}).get('appName', 'No app name')
        active = device.get('oauthConsumers', {}).get('active', 'No active status')
        created_at = device.get('createdAt', 'No creation date')
        print(f"[{index}] \033[92m {app_name} \033[0m (active={active} {created_at} )")
    selectdevice = int(input('Use Device: ')) -1    
    token = r.json()[selectdevice]['token']
    tokenSecret = r.json()[selectdevice]['tokenSecret']
    authToken = token + ':' + tokenSecret
    #print(authToken)
    return authToken


def encodeAuthToken(auth_token):
    s_bytes = auth_token.encode('ascii')
    base64_bytes = base64.b64encode(s_bytes)
    base64AuthToken = base64_bytes.decode('ascii')
    return base64AuthToken


def getServer(jwtToken, appKey, country, amount,timeoutms):
    url = f'{API}/servers/filters/74?filter_protocol=wireguard&filter_country={country}'
    header = {'x-app-key': appKey, 'Authorization': 'Bearer ' + jwtToken}
    r = requests.get(url, headers=header)
    servers = r.json()
    for sserv in servers:
        serverIP = sserv.get('ip')  
        connect_time_ms = get_connect_time_ms(serverIP, timeoutms)
        sserv['connect_time_ms'] = connect_time_ms
    #print (servers)    
    best = sorted(servers, key=lambda srv: (int(srv['Max_Users']) - int(srv['totalusers']), -float(srv['connect_time_ms'])), reverse=True)
    #best = [server for server in best if server['connect_time_ms'] != 999]
    best = [server for server in best if server['connect_time_ms'] <= timeoutms]
    for index, serv in enumerate(best, start=1):
        serv_name = serv.get('displayName', 'No data')
        #torrentblocked = serv.get('torrentblocked', 'No data')
        totalusers = serv.get('totalusers', 'No data')
        Max_Users = serv.get('Max_Users', 'No data')
        CTms = serv.get('connect_time_ms', 'No data')
        print(f"[{index}] \033[92m {serv_name} \033[0m ({totalusers}/{Max_Users} ) [{CTms}ms]")
    if amount == 1:
        selectserv = int(input('Use server: ')) -1
        return [best[selectserv]['name'].lower()]
    else:    
        return [server['name'].lower() for server in best[:amount]]
    
    

def get_connect_time_ms(serverIP, MAX_LATENCY_MS):
    MAX_LATENCY_S = MAX_LATENCY_MS / 1000.0  # Перетворення мілісекунд в секунди
    try:
        start_time = time.time()
        response = requests.get(f"http://{serverIP}:1337", timeout=MAX_LATENCY_S)
        end_time = time.time()
        connect_time_ms = round((end_time - start_time) * 1000.0)  # Перетворення секунд в мілісекунди
        return connect_time_ms
    except requests.exceptions.Timeout:
        return 999
    except requests.exceptions.RequestException as e:
        return 999


def genKeys():
    genKey = subprocess.run(['wg', 'genkey'], stdout=subprocess.PIPE)
    pubKey = subprocess.run(['wg', 'pubkey'], stdout=subprocess.PIPE, input=genKey.stdout)
    privateKey = genKey.stdout.decode('ascii').rstrip('\n')
    publicKey = pubKey.stdout.decode('ascii').rstrip('\n')
    return [privateKey, publicKey]


def getWireGuardConfig(server, base64AuthToken, publicKey):
    url = 'https://' + server + '.cg-dialup.net:1337/addKey?pubkey=' + urllib.parse.quote_plus(publicKey)
    header = {'Authorization': 'Basic ' + base64AuthToken}
    r = requests.get(url, headers=header, verify=False)
    address = r.json()['peer_ip']
    dns = r.json()['dns_servers'][0]
    peerPublicKey = r.json()['server_key']
    return [address, dns, peerPublicKey]


def printConfig(address, dns, privateKey, peerPublicKey, server, myip):
    print()
    print('-' * 80)
    print()
    print('[Interface]')
    print('Address = ' + address)
    print('DNS = ' + dns)
    print('PrivateKey = ' + privateKey + '\n')
    print('PostUp = ip -4 rule add from '+ myip +' lookup main prio 18')
    print('PostDown = ip -4 rule delete from '+ myip +' lookup main prio 18')

    print('[Peer]')
    print('PublicKey = ' + peerPublicKey)
    print('AllowedIPs = 0.0.0.0/0')
    print('Endpoint = ' + server + '.cg-dialup.net:1337')


STATIC_KEYS = ['', '']


def main():
    #parser = argparse.ArgumentParser()
    #parser.add_argument('country', type=str)
    #parser.add_argument('--new-keys', action='store_true')
    #parser.add_argument('--amount', type=int, default=1)
    geo='RU'
    country = input(f'Country [{geo}]: ') or geo
    iamount=1
    amount = int(input(f'Amount [{iamount}]: ') or iamount)
    #args = parser.parse_args()

    appKey = 'QzgDsDNUXlgF9jehkTHHtBJwwI4RyInkZQDRJfLyz'
    #username = input('Username: ')
    #password = getpass.getpass()
    username = 'soriasoriaaa@proton.me'
    password = "Soriasoriaaa123!"
    tims=100
    timeoutms = int(input(f'Timeout [{tims}ms]: ') or tims)
    
    jwtToken = login(username, password, appKey)
    servers = getServer(jwtToken, appKey, country, amount,timeoutms)
    #print(servers)
    
    #if args.new_keys:
    privateKey, publicKey = genKeys()
    #else:
        #privateKey, publicKey = STATIC_KEYS

    auth_token = encodeAuthToken(getDevice(jwtToken, appKey))
    getmyip=get_public_ip()
    myip = input(f'Your IP [{getmyip}]: ') or getmyip
    for server in servers:
        address, dns, peerPublicKey = getWireGuardConfig(server, auth_token, publicKey)
        printConfig(address, dns, privateKey, peerPublicKey, server, myip)


if __name__ == '__main__':
    main()
